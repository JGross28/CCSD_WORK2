﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Week2Assignment2
{
    public class ProfessorRating
    {
        public static void Main()
        {
            ProfessorRating PR = new ProfessorRating();
            Console.WriteLine("Please enter the professor ID: ");
            int professor_id = Convert.ToInt32(Console.ReadLine());    
            Console.Write("Enter helpfullness rating: ");
            double m_helpfullness = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter easiness rating: ");
            double m_easiness = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter Course Material rating: ");
            double m_courseMaterial = Convert.ToInt32(Console.ReadLine());
            double m_overallRating = (m_easiness + m_helpfullness + m_courseMaterial) / 3;
            Console.WriteLine("You overall rating for professor " + professor_id + " " + "is: " + m_overallRating);
            Console.ReadKey();
        }
    }
}
