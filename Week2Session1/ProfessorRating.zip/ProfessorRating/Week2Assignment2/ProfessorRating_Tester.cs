﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Week2Assignment2
{
    public class ProfessorRating_Test
    {
        private double m_easiness;
        private double m_helpfullness;
        private double m_courseMaterial;
        private double m_overallRating;
        private int m_id;

        public void ProfessorRating(int professor_id)
        {
            m_id = professor_id;
        }
        public int id
        {
            set
            {
                m_id = value;
            }
            get
            {
                return m_id;
            }
        }
    }
}
